#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

char* do_ls(char *);

int main(int ac,char *av[])
{
    char* file_name;
    if(ac == 1){
        printf("There is no file\n");
    }
    else
    {
        for(; ac > 1; ac --)
        {
            printf("%s:\n",*++av);
            while(file_name = do_ls(*av)){
                printf("%s\n",file_name);
            }
        }
    }
    return 0;
}

char*  do_ls(char dirname[])                                //返回文件夹中的一个文件名（此文件名未返回过）
{
    char* get_name;
    static char have_name[1024];
    DIR *dir_ptr;
    struct dirent *direntp;
    dir_ptr = opendir(dirname);
    if(dir_ptr == NULL)
    {
        printf("Ls: can not open %s\n",dirname);
    }
    else
    {
        while(direntp = readdir(dir_ptr))
        {
            if(strcmp(direntp->d_name, "..") == 0 || strcmp(direntp->d_name,".") == 0){
                continue;
            }
            else if(strstr(have_name,direntp->d_name)){
                continue;
            }
            else{
                strcat(have_name, direntp->d_name);
                get_name = direntp->d_name;
                closedir(dir_ptr);
                return get_name;
            }
        }
    }
}

